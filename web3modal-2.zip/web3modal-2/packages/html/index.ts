export { Web3Modal } from './src/client'
export type { Web3ModalConfig } from './src/client'

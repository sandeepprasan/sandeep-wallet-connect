export { Web3Modal } from './src/client'
